Prefabs folder (the game objects are built from code at Play time, so this is intentionally empty).
