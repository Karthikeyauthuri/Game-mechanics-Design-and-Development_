Models folder. The car and world are built from Unity primitives. Drop your own 3D models here.
