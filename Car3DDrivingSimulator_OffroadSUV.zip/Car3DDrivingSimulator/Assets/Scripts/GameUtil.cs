using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Small helper functions used by the other scripts:
/// loading materials, creating simple 3D shapes from Unity primitives, and the UI font.
/// </summary>
public static class GameUtil
{
    static Font cachedFont;
    static readonly Dictionary<string, Material> materialCache = new Dictionary<string, Material>();
    static readonly Dictionary<PrimitiveType, Mesh> meshCache = new Dictionary<PrimitiveType, Mesh>();

    public static Font UIFont
    {
        get
        {
            if (cachedFont == null)
            {
                cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (cachedFont == null) cachedFont = Font.CreateDynamicFontFromOSFont("Arial", 32);
            }
            return cachedFont;
        }
    }

    /// <summary>Returns a shared material. Uses the .mat file in Assets/Materials/Resources if present.</summary>
    public static Material GetMaterial(string name, Color color)
    {
        Material cached;
        if (materialCache.TryGetValue(name, out cached) && cached != null) return cached;
        Material mat = NewMaterial(name, color);
        materialCache[name] = mat;
        return mat;
    }

    /// <summary>Creates a brand new (unshared) material.</summary>
    public static Material NewMaterial(string name, Color color)
    {
        Material template = Resources.Load<Material>(name);
        Material mat = null;
        if (template != null && template.shader != null && template.shader.name == "Standard")
            mat = new Material(template);
        if (mat == null)
        {
            Shader s = Shader.Find("Standard");
            if (s == null) s = Shader.Find("Legacy Shaders/Diffuse");
            if (s == null) s = Shader.Find("Unlit/Color");
            mat = new Material(s);
        }
        mat.name = name;
        mat.color = color;
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.3f);
        return mat;
    }

    /// <summary>Returns the procedural skybox material (or null if it cannot be created).</summary>
    public static Material GetSkybox()
    {
        Material template = Resources.Load<Material>("SkyProcedural");
        if (template != null && template.shader != null && template.shader.name == "Skybox/Procedural")
            return template;
        Shader s = Shader.Find("Skybox/Procedural");
        if (s == null) return null;
        Material m = new Material(s);
        m.SetFloat("_SunSize", 0.04f);
        m.SetFloat("_AtmosphereThickness", 1.0f);
        m.SetFloat("_Exposure", 1.3f);
        return m;
    }

    public static Mesh GetMesh(PrimitiveType type)
    {
        Mesh m;
        if (!meshCache.TryGetValue(type, out m) || m == null)
        {
            GameObject tmp = GameObject.CreatePrimitive(type);
            m = tmp.GetComponent<MeshFilter>().sharedMesh;
            Object.Destroy(tmp);
            meshCache[type] = m;
        }
        return m;
    }

    /// <summary>Creates a renderer-only shape (no collider) as a child of parent.</summary>
    public static GameObject Visual(PrimitiveType type, string name, Transform parent, Vector3 localPos, Vector3 localScale, Material mat)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = localScale;
        go.AddComponent<MeshFilter>().sharedMesh = GetMesh(type);
        go.AddComponent<MeshRenderer>().sharedMaterial = mat;
        return go;
    }

    /// <summary>Creates a box at a world position / rotation, optionally with a BoxCollider.</summary>
    public static GameObject Box(string name, Transform parent, Vector3 worldPos, Quaternion worldRot, Vector3 size, Material mat, bool collider)
    {
        GameObject go = Visual(PrimitiveType.Cube, name, parent, Vector3.zero, size, mat);
        go.transform.SetPositionAndRotation(worldPos, worldRot);
        if (collider) go.AddComponent<BoxCollider>();
        return go;
    }
}
