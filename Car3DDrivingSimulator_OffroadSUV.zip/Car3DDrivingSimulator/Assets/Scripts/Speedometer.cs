using UnityEngine;
using UnityEngine.UI;

/// <summary>Shows the car speed (km/h) as a number and a coloured bar.</summary>
public class Speedometer : MonoBehaviour
{
    public CarController car;
    public Text speedText;
    public RectTransform barFill;
    public Image barImage;
    public float maxDisplayKmh = 110f;

    void Update()
    {
        if (car == null || speedText == null) return;
        float kmh = car.SpeedKmh;
        speedText.text = Mathf.RoundToInt(kmh).ToString();
        float t = Mathf.Clamp01(kmh / maxDisplayKmh);
        if (barFill != null) barFill.anchorMax = new Vector2(t, 1f);
        if (barImage != null) barImage.color = Color.Lerp(new Color(0.2f, 0.9f, 0.3f), new Color(1f, 0.25f, 0.2f), t);
    }
}
