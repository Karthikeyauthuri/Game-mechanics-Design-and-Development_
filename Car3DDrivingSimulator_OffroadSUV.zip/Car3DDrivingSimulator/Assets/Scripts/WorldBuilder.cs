using UnityEngine;

/// <summary>
/// Builds the whole 3D world from Unity primitives: road, lane lines, grass, rails, trees,
/// streetlights, start/finish lines, checkpoints, cones, barriers and traffic.
/// </summary>
public static class WorldBuilder
{
    public const float RoadWidth = 12f;
    public const float StartDistance = 6f;
    public const float StartLineDistance = 16f;
    public const float PlayerLane = 3f;

    static Texture2D grassTexture;

    public static float FinishDistance(TrackPath path) { return path.Length - 20f; }

    static Material M(string name, float r, float g, float b)
    {
        return GameUtil.GetMaterial(name, new Color(r, g, b, 1f));
    }

    public static TrackPath CreateTrackPath()
    {
        Vector3[] c = new Vector3[]
        {
            new Vector3(0, 0, 0), new Vector3(0, 0, 80), new Vector3(10, 0, 160), new Vector3(50, 0, 230),
            new Vector3(120, 0, 270), new Vector3(200, 0, 280), new Vector3(270, 0, 320), new Vector3(290, 0, 400),
            new Vector3(250, 0, 480), new Vector3(170, 0, 530), new Vector3(90, 0, 580), new Vector3(60, 0, 660),
            new Vector3(90, 0, 740), new Vector3(160, 0, 790), new Vector3(240, 0, 800), new Vector3(320, 0, 830),
            new Vector3(350, 0, 900), new Vector3(350, 0, 980)
        };
        return new TrackPath(c);
    }

    static Texture2D MakeGrassTexture()
    {
        if (grassTexture != null) return grassTexture;
        int size = 64;
        Texture2D t = new Texture2D(size, size, TextureFormat.RGB24, true);
        System.Random r = new System.Random(7);
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float n = 0.82f + (float)r.NextDouble() * 0.36f;
                t.SetPixel(x, y, new Color(0.27f * n, 0.58f * n, 0.21f * n));
            }
        t.wrapMode = TextureWrapMode.Repeat;
        t.filterMode = FilterMode.Bilinear;
        t.Apply(true);
        grassTexture = t;
        return t;
    }

    static float R(System.Random r) { return (float)r.NextDouble(); }

    // ------------------------------------------------------------------ environment

    public static void BuildEnvironment(Transform parent, TrackPath path)
    {
        GameObject sceneryGO = new GameObject("Scenery");
        sceneryGO.transform.SetParent(parent, false);
        Transform scenery = sceneryGO.transform;
        float L = path.Length;
        float halfW = RoadWidth * 0.5f;

        Material asphalt = M("Asphalt", 0.17f, 0.17f, 0.19f);
        Material grass = M("Grass", 1f, 1f, 1f);
        Material lineWhite = M("LineWhite", 0.95f, 0.95f, 0.95f);
        Material lineYellow = M("LineYellow", 0.95f, 0.8f, 0.1f);
        Material railRed = M("RailRed", 0.85f, 0.15f, 0.12f);
        Material railWhite = M("RailWhite", 0.93f, 0.93f, 0.93f);
        Material concrete = M("Concrete", 0.6f, 0.6f, 0.62f);
        Material trunk = M("TreeTrunk", 0.4f, 0.26f, 0.13f);
        Material leafA = M("LeafA", 0.15f, 0.5f, 0.15f);
        Material leafB = M("LeafB", 0.2f, 0.62f, 0.2f);
        Material pole = M("Pole", 0.35f, 0.37f, 0.4f);
        Material lamp = M("LampGlow", 1f, 0.95f, 0.7f);

        // Ground (grass). Its collider is the floor the car drives on.
        Bounds b = path.GetBounds();
        float sx = b.size.x + 900f;
        float sz = b.size.z + 900f;
        grass.mainTexture = MakeGrassTexture();
        grass.mainTextureScale = new Vector2(sx / 6f, sz / 6f);
        GameUtil.Box("Ground", scenery, new Vector3(b.center.x, -0.5f, b.center.z), Quaternion.identity, new Vector3(sx, 1f, sz), grass, true);

        // Road, lane lines and guard rails, one 8 m piece at a time.
        float seg = 8f;
        float roadEnd = L + 14f;
        float d = -8f;
        int idx = 0;
        while (d < roadEnd)
        {
            float mid = d + seg * 0.5f;
            Vector3 pos, fwd;
            path.Evaluate(mid, 0f, out pos, out fwd);
            Quaternion rot = Quaternion.LookRotation(fwd, Vector3.up);
            Vector3 right = rot * Vector3.right;

            GameUtil.Box("Road", scenery, pos + Vector3.up * -0.04f, rot, new Vector3(RoadWidth, 0.2f, seg + 1.2f), asphalt, false);
            if (idx % 2 == 0)
                GameUtil.Box("CenterDash", scenery, pos + Vector3.up * 0.08f, rot, new Vector3(0.25f, 0.04f, seg * 0.5f), lineYellow, false);
            for (int s = -1; s <= 1; s += 2)
            {
                GameUtil.Box("EdgeLine", scenery, pos + right * (s * (halfW - 0.5f)) + Vector3.up * 0.08f, rot, new Vector3(0.25f, 0.04f, seg + 0.6f), lineWhite, false);
                GameUtil.Box("Rail", scenery, pos + right * (s * (halfW + 0.6f)) + Vector3.up * 0.5f, rot, new Vector3(0.4f, 1f, seg + 1.2f), (idx % 2 == 0) ? railRed : railWhite, true);
            }
            d += seg;
            idx++;
        }
        BuildWall(scenery, path, -8.5f, concrete);
        BuildWall(scenery, path, d + 0.5f, concrete);

        // Trees on both sides.
        System.Random rng = new System.Random(12345);
        for (float td = 10f; td < L; td += 14f)
        {
            for (int side = -1; side <= 1; side += 2)
            {
                float lat = side * (halfW + 6f + R(rng) * 22f);
                Vector3 pos, fwd;
                path.Evaluate(td + R(rng) * 6f, lat, out pos, out fwd);
                float sc = 0.8f + R(rng) * 0.9f;
                GameUtil.Visual(PrimitiveType.Cylinder, "Trunk", scenery, new Vector3(pos.x, 2f * sc, pos.z), new Vector3(0.45f * sc, 2f * sc, 0.45f * sc), trunk);
                GameUtil.Visual(PrimitiveType.Sphere, "Crown", scenery, new Vector3(pos.x, 5.2f * sc, pos.z), new Vector3(4.2f * sc, 4.2f * sc, 4.2f * sc), leafA);
                GameUtil.Visual(PrimitiveType.Sphere, "CrownTop", scenery, new Vector3(pos.x, 7.3f * sc, pos.z), new Vector3(3f * sc, 3f * sc, 3f * sc), leafB);
            }
        }

        // Streetlights every 50 m, alternating sides.
        int k = 0;
        for (float ld = 25f; ld < L; ld += 50f, k++)
        {
            int side = (k % 2 == 0) ? 1 : -1;
            Vector3 pos, fwd;
            path.Evaluate(ld, side * (halfW + 2.2f), out pos, out fwd);
            GameObject root = new GameObject("StreetLight");
            root.transform.SetParent(scenery, false);
            root.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(fwd, Vector3.up));
            Transform rt = root.transform;
            GameUtil.Visual(PrimitiveType.Cylinder, "Pole", rt, new Vector3(0f, 3.2f, 0f), new Vector3(0.14f, 3.2f, 0.14f), pole);
            GameUtil.Visual(PrimitiveType.Cube, "Arm", rt, new Vector3(-side * 0.9f, 6.4f, 0f), new Vector3(1.8f, 0.12f, 0.12f), pole);
            GameUtil.Visual(PrimitiveType.Cube, "Lamp", rt, new Vector3(-side * 1.7f, 6.32f, 0f), new Vector3(0.7f, 0.12f, 0.4f), lamp);
        }

        try { StaticBatchingUtility.Combine(sceneryGO); }
        catch (System.Exception e) { Debug.LogWarning("Static batching skipped: " + e.Message); }
    }

    static void BuildWall(Transform parent, TrackPath path, float dist, Material mat)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, 0f, out pos, out fwd);
        GameUtil.Box("EndWall", parent, pos + Vector3.up * 0.75f, Quaternion.LookRotation(fwd, Vector3.up), new Vector3(RoadWidth + 3f, 1.5f, 0.8f), mat, true);
    }

    // ------------------------------------------------------------------ gates, start & finish

    static Renderer BuildGate(Transform parent, TrackPath path, float dist, string label, Material beamMat, Color textColor)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, 0f, out pos, out fwd);
        GameObject root = new GameObject("Gate_" + label);
        root.transform.SetParent(parent, false);
        root.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(fwd, Vector3.up));
        Transform rt = root.transform;
        Material pole = M("Pole", 0.35f, 0.37f, 0.4f);
        float half = RoadWidth * 0.5f + 1.3f;
        GameUtil.Visual(PrimitiveType.Cylinder, "PoleL", rt, new Vector3(-half, 3.5f, 0f), new Vector3(0.45f, 3.5f, 0.45f), pole);
        GameUtil.Visual(PrimitiveType.Cylinder, "PoleR", rt, new Vector3(half, 3.5f, 0f), new Vector3(0.45f, 3.5f, 0.45f), pole);
        GameObject beam = GameUtil.Visual(PrimitiveType.Cube, "Beam", rt, new Vector3(0f, 7.2f, 0f), new Vector3(half * 2f + 0.8f, 1.5f, 0.4f), beamMat);

        GameObject txt = new GameObject("Label");
        txt.transform.SetParent(rt, false);
        txt.transform.localPosition = new Vector3(0f, 7.2f, -0.25f);
        TextMesh tm = txt.AddComponent<TextMesh>();
        tm.text = label;
        tm.fontSize = 80;
        tm.characterSize = 0.12f;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.alignment = TextAlignment.Center;
        tm.color = textColor;
        tm.font = GameUtil.UIFont;
        MeshRenderer mr = txt.GetComponent<MeshRenderer>();
        if (mr != null && tm.font != null) mr.sharedMaterial = tm.font.material;
        return beam.GetComponent<Renderer>();
    }

    static void BuildCheckerStrip(Transform parent, TrackPath path, float dist)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, 0f, out pos, out fwd);
        GameObject root = new GameObject("CheckerStrip");
        root.transform.SetParent(parent, false);
        root.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(fwd, Vector3.up));
        Material black = M("CheckerBlack", 0.05f, 0.05f, 0.05f);
        Material white = M("CheckerWhite", 0.95f, 0.95f, 0.95f);
        int cols = 16;
        float sq = RoadWidth / cols;
        for (int c = 0; c < cols; c++)
            for (int r = 0; r < 2; r++)
                GameUtil.Visual(PrimitiveType.Cube, "Check", root.transform,
                    new Vector3(-RoadWidth * 0.5f + sq * (c + 0.5f), 0.08f, (r - 0.5f) * sq),
                    new Vector3(sq, 0.04f, sq), ((c + r) % 2 == 0) ? black : white);
    }

    public static void BuildStart(Transform parent, TrackPath path)
    {
        Vector3 pos, fwd;
        path.Evaluate(StartLineDistance, 0f, out pos, out fwd);
        GameUtil.Box("StartLine", parent, pos + Vector3.up * 0.08f, Quaternion.LookRotation(fwd, Vector3.up), new Vector3(RoadWidth, 0.04f, 0.6f), M("LineWhite", 0.95f, 0.95f, 0.95f), false);
        BuildGate(parent, path, StartLineDistance, "START", M("BannerGreen", 0.1f, 0.6f, 0.2f), Color.white);
    }

    static GameObject MakeTrigger(Transform parent, TrackPath path, float dist, string name)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, 0f, out pos, out fwd);
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(fwd, Vector3.up));
        BoxCollider bc = go.AddComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.center = new Vector3(0f, 4f, 0f);
        bc.size = new Vector3(RoadWidth + 2f, 8f, 1.5f);
        return go;
    }

    public static FinishLine BuildFinish(Transform parent, TrackPath path, GameManager gm)
    {
        float d = FinishDistance(path);
        BuildCheckerStrip(parent, path, d);
        BuildGate(parent, path, d, "FINISH", M("Banner", 0.08f, 0.08f, 0.1f), Color.white);
        GameObject trig = MakeTrigger(parent, path, d, "FinishTrigger");
        FinishLine fl = trig.AddComponent<FinishLine>();
        fl.gameManager = gm;
        return fl;
    }

    public static void BuildCheckpoints(Transform parent, TrackPath path, CheckpointManager mgr)
    {
        float[] dists = { 215f, 455f, 715f, 890f, 1060f, 1215f };
        Material blue = M("CheckpointBlue", 0.1f, 0.45f, 0.95f);
        Material green = M("CheckpointGreen", 0.2f, 0.9f, 0.3f);
        float limit = FinishDistance(path) - 30f;
        int index = 0;
        for (int i = 0; i < dists.Length; i++)
        {
            if (dists[i] > limit) continue;
            Renderer beam = BuildGate(parent, path, dists[i], "CHECKPOINT " + (index + 1), blue, Color.white);
            GameObject trig = MakeTrigger(parent, path, dists[i], "CheckpointTrigger" + (index + 1));
            Checkpoint cp = trig.AddComponent<Checkpoint>();
            cp.index = index;
            cp.distance = dists[i];
            cp.manager = mgr;
            cp.beam = beam;
            cp.passedMaterial = green;
            mgr.Register(cp);
            index++;
        }
    }

    // ------------------------------------------------------------------ obstacles

    static void Cone(Transform parent, Vector3 pos, Quaternion rot)
    {
        Material orange = M("ConeOrange", 1f, 0.4f, 0.05f);
        Material white = M("ConeWhite", 0.95f, 0.95f, 0.95f);
        Material dark = M("ConeBase", 0.15f, 0.15f, 0.15f);
        GameObject c = new GameObject("TrafficCone");
        c.transform.SetParent(parent, false);
        c.transform.SetPositionAndRotation(pos + Vector3.up * 0.01f, rot);
        Transform t = c.transform;
        GameUtil.Visual(PrimitiveType.Cube, "Base", t, new Vector3(0f, 0.03f, 0f), new Vector3(0.55f, 0.06f, 0.55f), dark);
        GameUtil.Visual(PrimitiveType.Cylinder, "Lower", t, new Vector3(0f, 0.24f, 0f), new Vector3(0.26f, 0.18f, 0.26f), orange);
        GameUtil.Visual(PrimitiveType.Cylinder, "Stripe", t, new Vector3(0f, 0.46f, 0f), new Vector3(0.21f, 0.05f, 0.21f), white);
        GameUtil.Visual(PrimitiveType.Cylinder, "Upper", t, new Vector3(0f, 0.66f, 0f), new Vector3(0.14f, 0.15f, 0.14f), orange);
        Rigidbody rb = c.AddComponent<Rigidbody>();
        rb.mass = 2f;
        BoxCollider bc = c.AddComponent<BoxCollider>();
        bc.center = new Vector3(0f, 0.4f, 0f);
        bc.size = new Vector3(0.5f, 0.8f, 0.5f);
    }

    static void ConeAt(Transform t, TrackPath path, float dist, float lat)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, lat, out pos, out fwd);
        Cone(t, pos, Quaternion.LookRotation(fwd, Vector3.up));
    }

    static void ConeRow(Transform t, TrackPath path, float dist, float latFrom, float latTo, int count, float limit)
    {
        if (dist > limit) return;
        for (int i = 0; i < count; i++)
            ConeAt(t, path, dist, Mathf.Lerp(latFrom, latTo, count == 1 ? 0f : (float)i / (count - 1)));
    }

    static void Barrier(Transform t, TrackPath path, float dist, float lat, float width, float limit)
    {
        if (dist > limit) return;
        Vector3 pos, fwd;
        path.Evaluate(dist, lat, out pos, out fwd);
        Quaternion rot = Quaternion.LookRotation(fwd, Vector3.up);
        GameUtil.Box("ConcreteBarrier", t, pos + Vector3.up * 0.45f, rot, new Vector3(width, 0.9f, 0.7f), M("Concrete", 0.6f, 0.6f, 0.62f), true);
        GameUtil.Box("BarrierStripe", t, pos + Vector3.up * 0.93f, rot, new Vector3(width, 0.1f, 0.72f), M("ConeOrange", 1f, 0.4f, 0.05f), false);
    }

    static readonly Color[] CarColors =
    {
        new Color(0.1f, 0.35f, 0.85f), new Color(0.95f, 0.8f, 0.1f), new Color(0.2f, 0.7f, 0.3f),
        new Color(0.9f, 0.9f, 0.92f), new Color(0.15f, 0.15f, 0.18f), new Color(0.6f, 0.2f, 0.7f)
    };

    static void BrokenCar(Transform t, TrackPath path, float dist, float lat, float yaw, int colorIndex, float limit)
    {
        if (dist > limit) return;
        Vector3 pos, fwd;
        path.Evaluate(dist, lat, out pos, out fwd);
        Quaternion rot = Quaternion.LookRotation(fwd, Vector3.up) * Quaternion.Euler(0f, yaw, 0f);
        int ci = colorIndex % CarColors.Length;
        CarBuilder.CreateStaticCar(t, pos, rot, CarColors[ci], ci.ToString());
        ConeAt(t, path, dist - 12f, lat - 1f);
        ConeAt(t, path, dist - 12f, lat);
        ConeAt(t, path, dist - 12f, lat + 1f);
    }

    public static void BuildObstacles(Transform parent, TrackPath path)
    {
        GameObject root = new GameObject("Obstacles");
        root.transform.SetParent(parent, false);
        Transform t = root.transform;
        float limit = path.Length - 70f;

        ConeRow(t, path, 100f, 1.5f, 5.5f, 5, limit);
        BrokenCar(t, path, 180f, -3f, 6f, 0, limit);
        Barrier(t, path, 250f, 3f, 2.6f, limit);
        ConeRow(t, path, 330f, -5.5f, -1.5f, 5, limit);
        Barrier(t, path, 410f, -1f, 2f, limit);
        Barrier(t, path, 410f, 1f, 2f, limit);
        BrokenCar(t, path, 500f, 3f, -8f, 1, limit);
        ConeRow(t, path, 590f, 0.5f, 5.5f, 6, limit);
        Barrier(t, path, 670f, -3f, 2.6f, limit);
        ConeRow(t, path, 760f, -5f, -1f, 5, limit);
        BrokenCar(t, path, 850f, -3f, 5f, 2, limit);
        Barrier(t, path, 930f, -1f, 2f, limit);
        Barrier(t, path, 930f, 1f, 2f, limit);
        ConeRow(t, path, 1010f, 1f, 5f, 5, limit);
        BrokenCar(t, path, 1100f, 3f, -6f, 3, limit);
        Barrier(t, path, 1180f, -3f, 2.6f, limit);
        ConeRow(t, path, 1250f, -5f, -1f, 5, limit);
    }

    public static void BuildTraffic(Transform parent, TrackPath path)
    {
        GameObject root = new GameObject("Traffic");
        root.transform.SetParent(parent, false);
        // start distance, lane, speed (m/s), stop distance
        float[,] data = new float[,]
        {
            { 30f, -3f, 7f, 150f }, { 195f, -3f, 8f, 315f }, { 270f, 3f, 8f, 400f },
            { 430f, -3f, 8f, 640f }, { 660f, 3f, 9f, 980f }, { 880f, -3f, 8f, 1150f },
            { 1120f, 3f, 9f, 1300f }
        };
        float limit = path.Length - 70f;
        for (int i = 0; i < data.GetLength(0); i++)
        {
            if (data[i, 0] > limit) continue;
            int ci = (i + 2) % CarColors.Length;
            CarBuilder.CreateTrafficCar(root.transform, path, data[i, 0], data[i, 1], data[i, 2], data[i, 3], CarColors[ci], ci.ToString());
        }
    }
}
