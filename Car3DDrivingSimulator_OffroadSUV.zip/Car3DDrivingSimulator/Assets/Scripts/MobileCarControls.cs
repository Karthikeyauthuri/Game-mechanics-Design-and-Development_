using UnityEngine;

/// <summary>
/// Holds the state of the on-screen buttons (Left, Right, Accelerate, Reverse, Brake).
/// The buttons are created by UIBuilder; CarController reads these static values every frame.
/// </summary>
public class MobileCarControls : MonoBehaviour
{
    public static bool Left, Right, Accelerate, Reverse, Brake;

    public static void ResetAll() { Left = Right = Accelerate = Reverse = Brake = false; }

    public void SetLeft(bool v) { Left = v; }
    public void SetRight(bool v) { Right = v; }
    public void SetAccelerate(bool v) { Accelerate = v; }
    public void SetReverse(bool v) { Reverse = v; }
    public void SetBrake(bool v) { Brake = v; }

    void OnDisable() { ResetAll(); }
}
