using UnityEngine;
using UnityEngine.UI;

public enum GameState { Title, Playing, Paused, Completed, GameOver }

/// <summary>Controls the game flow: title, playing, pause, level completed, game over, restart, car health and HUD.</summary>
public class GameManager : MonoBehaviour
{
    public GameState state = GameState.Title;

    [Header("References (filled automatically at start)")]
    public CarController car;
    public CameraFollow cameraFollow;
    public CheckpointManager checkpoints;
    public TrackPath path;
    public GameBootstrap bootstrap;

    [Header("Level")]
    public float startDistance = 6f;
    public float finishDistance = 1400f;
    public float maxHealth = 100f;

    [Header("UI (filled automatically by UIBuilder)")]
    public GameObject titlePanel, hudPanel, pausePanel, completePanel, gameOverPanel;
    public Text distanceText, timeText, checkpointText, messageText, completeStatsText, healthText;
    public RectTransform progressFill, healthFill;
    public Image healthFillImage, damageFlash;

    float health;
    float elapsed;
    float progressDist;
    float messageTimer;
    float flashAlpha;

    public void Begin(bool autoStart)
    {
        health = maxHealth;
        progressDist = startDistance;
        car.OnCrash += HandleCrash;
        checkpoints.OnCheckpointPassed += HandleCheckpoint;
        if (autoStart) StartGame(); else ApplyState(GameState.Title);
        UpdateHud();
    }

    void ApplyState(GameState s)
    {
        state = s;
        titlePanel.SetActive(s == GameState.Title);
        hudPanel.SetActive(s != GameState.Title);
        pausePanel.SetActive(s == GameState.Paused);
        completePanel.SetActive(s == GameState.Completed);
        gameOverPanel.SetActive(s == GameState.GameOver);
        car.inputEnabled = (s == GameState.Playing);
        bool paused = (s == GameState.Paused);
        Time.timeScale = paused ? 0f : 1f;
        AudioListener.pause = paused;
        MobileCarControls.ResetAll();
    }

    // ---------------------------------------------------------------- buttons

    public void StartGame() { elapsed = 0f; ApplyState(GameState.Playing); }
    public void Pause() { if (state == GameState.Playing) ApplyState(GameState.Paused); }
    public void Resume() { if (state == GameState.Paused) ApplyState(GameState.Playing); }
    public void RestartLevel() { Time.timeScale = 1f; AudioListener.pause = false; bootstrap.Restart(true); }
    public void GoToMainMenu() { Time.timeScale = 1f; AudioListener.pause = false; bootstrap.Restart(false); }

    public void RetryFromCheckpoint()
    {
        health = maxHealth;
        Respawn();
        ApplyState(GameState.Playing);
    }

    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ---------------------------------------------------------------- events

    public void CompleteLevel()
    {
        if (state != GameState.Playing) return;
        if (checkpoints.Passed < checkpoints.Total)
        {
            ShowMessage("Missed a checkpoint! Go back and pass all gates.", 3f);
            return;
        }
        completeStatsText.text = "Time: " + FormatTime(elapsed) +
            "\nCheckpoints: " + checkpoints.Passed + " / " + checkpoints.Total +
            "\nCar condition: " + Mathf.RoundToInt(health / maxHealth * 100f) + "%";
        ApplyState(GameState.Completed);
    }

    void HandleCrash(float impact)
    {
        if (state != GameState.Playing) return;
        health -= (impact - 2f) * 2.5f;
        flashAlpha = 0.6f;
        if (health <= 0f)
        {
            health = 0f;
            ApplyState(GameState.GameOver);
        }
    }

    void HandleCheckpoint(int passed, int total)
    {
        ShowMessage("CHECKPOINT " + passed + " / " + total, 2f);
    }

    void Respawn()
    {
        Vector3 pos;
        Quaternion rot;
        checkpoints.GetRespawnPose(out pos, out rot);
        car.ResetCar(pos, rot);
        progressDist = checkpoints.respawnDistance;
        cameraFollow.SnapToTarget();
    }

    public void ShowMessage(string text, float seconds)
    {
        messageText.text = text;
        messageTimer = seconds;
    }

    // ---------------------------------------------------------------- update

    void Update()
    {
        TrafficCar.Running = (state == GameState.Playing);
        if (car == null) return;

        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (state == GameState.Playing) Pause();
            else if (state == GameState.Paused) Resume();
        }

        if (state != GameState.Title)
            progressDist = path.Project(car.transform.position, progressDist);
        if (state == GameState.Playing)
        {
            elapsed += Time.deltaTime;
            if (car.transform.position.y < -3f) Respawn();
        }

        if (messageTimer > 0f)
        {
            messageTimer -= Time.unscaledDeltaTime;
            if (messageTimer <= 0f) messageText.text = "";
        }
        flashAlpha = Mathf.MoveTowards(flashAlpha, 0f, Time.unscaledDeltaTime * 1.5f);
        damageFlash.color = new Color(1f, 0f, 0f, flashAlpha);
        UpdateHud();
    }

    static string FormatTime(float t)
    {
        return string.Format("{0:00}:{1:00}", (int)(t / 60f), (int)(t % 60f));
    }

    void UpdateHud()
    {
        float total = Mathf.Max(1f, finishDistance - startDistance);
        float travelled = Mathf.Clamp(progressDist - startDistance, 0f, total);
        distanceText.text = "DISTANCE  " + Mathf.RoundToInt(travelled) + " / " + Mathf.RoundToInt(total) + " m";
        progressFill.anchorMax = new Vector2(travelled / total, 1f);
        timeText.text = "TIME " + FormatTime(elapsed);
        checkpointText.text = "CHECKPOINTS " + checkpoints.Passed + " / " + checkpoints.Total;
        float h = Mathf.Clamp01(health / maxHealth);
        healthFill.anchorMax = new Vector2(h, 1f);
        healthFillImage.color = Color.Lerp(new Color(1f, 0.2f, 0.15f), new Color(0.2f, 0.9f, 0.3f), h);
        healthText.text = "CAR " + Mathf.RoundToInt(h * 100f) + "%";
    }
}
