Textures folder. The grass texture is generated in code. Drop your own textures here.
