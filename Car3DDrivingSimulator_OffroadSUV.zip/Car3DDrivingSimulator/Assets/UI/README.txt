UI folder. The UI is built in code (see Scripts/UIBuilder.cs). Drop your own UI sprites here.
